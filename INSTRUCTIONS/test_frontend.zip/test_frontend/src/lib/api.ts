// Example types you might adjust as your schema evolves:
type Item = {
  itemId: string;
  type: string;
  data: any;
};

type Collection = {
  name: string;
  isPublic: boolean;
  itemCount: number;
  shortId: string;
  collectionId: string;
};

interface FetchItemsResponse {
  items: Item[];
  collections: Collection[];
}

interface FetchItemsArgs {
  page: number;
  PAGE_SIZE: number;
  filters: Record<string, any>;
  token?: string;
  selectedCollectionId?: string | null;
}

// API call function
export async function fetchItems({
  page,
  PAGE_SIZE,
  filters,
  token,
  selectedCollectionId,
}: FetchItemsArgs): Promise<FetchItemsResponse> {
  const GRAPHQL_ENDPOINT = 'https://clip-api-119123333996.us-central1.run.app/graphql';

  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
  };

  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  const resp = await fetch(GRAPHQL_ENDPOINT, {
    method: 'POST',
    headers,
    body: JSON.stringify({
      query: `
        query MyQuery($limit: Int, $offset: Int, $filters: ItemFilters) {
          items(limit: $limit, offset: $offset, filters: $filters) {
            itemId
            type
            data
          }
          collections {
            name
            isPublic
            itemCount
            shortId
            collectionId
          }
        }
      `,
      variables: {
        limit: PAGE_SIZE,
        offset: page * PAGE_SIZE,
        filters: {
          ...filters,
          ...(selectedCollectionId ? { collectionId: selectedCollectionId } : {}),
        },
      },
    }),
  });

  if (!resp.ok) {
    throw new Error(`Request failed with status ${resp.status}`);
  }

  const json = await resp.json();
  return json.data;
} 