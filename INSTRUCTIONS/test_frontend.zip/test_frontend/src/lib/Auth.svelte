<script>
  import { auth, googleProvider, user } from './firebase';
  import { createEventDispatcher } from 'svelte';
  import { 
    signInWithEmailAndPassword,
    createUserWithEmailAndPassword,
    signInWithPopup,
    signOut
  } from 'firebase/auth';

  const dispatch = createEventDispatcher();
  let email = '';
  let password = '';
  let error = '';

  // Watch for auth state changes and dispatch event
  user.subscribe((newUser) => {
    dispatch('authStateChange', { user: newUser });
  });

  async function handleEmailSignIn() {
    try {
      error = '';
      await signInWithEmailAndPassword(auth, email, password);
    } catch (e) {
      error = e.message;
    }
  }

  async function handleEmailSignUp() {
    try {
      error = '';
      await createUserWithEmailAndPassword(auth, email, password);
    } catch (e) {
      error = e.message;
    }
  }

  async function handleGoogleSignIn() {
    try {
      error = '';
      await signInWithPopup(auth, googleProvider);
    } catch (e) {
      error = e.message;
    }
  }

  async function handleSignOut() {
    try {
      error = '';
      await signOut(auth);
    } catch (e) {
      error = e.message;
    }
  }
</script>

<div class="auth-container">
  {#if $user}
    <div class="user-info">
      <p>Signed in as: {$user.email}</p>
      <button on:click={handleSignOut}>Sign Out</button>
    </div>
  {:else}
    <div class="auth-form">
      <input
        type="email"
        placeholder="Email"
        bind:value={email}
      />
      <input
        type="password"
        placeholder="Password"
        bind:value={password}
      />
      <div class="button-group">
        <button on:click={handleEmailSignIn}>Sign In</button>
        <button on:click={handleEmailSignUp}>Sign Up</button>
        <button on:click={handleGoogleSignIn}>Sign in with Google</button>
      </div>
    </div>
  {/if}
  
  {#if error}
    <div class="error">
      {error}
    </div>
  {/if}
</div>

<style>
  .auth-container {
    padding: 1rem;
    max-width: 400px;
    margin: 0 auto;
  }

  .auth-form {
    display: flex;
    flex-direction: column;
    gap: 1rem;
  }

  input {
    padding: 0.5rem;
    border: 1px solid #ccc;
    border-radius: 4px;
  }

  .button-group {
    display: flex;
    flex-direction: column;
    gap: 0.5rem;
  }

  button {
    padding: 0.5rem 1rem;
    border: none;
    border-radius: 4px;
    background-color: #4285f4;
    color: white;
    cursor: pointer;
  }

  button:hover {
    background-color: #357abd;
  }

  .error {
    color: red;
    margin-top: 1rem;
  }

  .user-info {
    text-align: center;
  }
</style> 