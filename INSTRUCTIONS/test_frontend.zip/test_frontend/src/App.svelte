<script>
  import Router from 'svelte-spa-router';
  import Login from './routes/Login.svelte';
  import App from './routes/App.svelte';

  const routes = {
    '/': Login,
    '/app': App,
  };
</script>

<Router {routes} />