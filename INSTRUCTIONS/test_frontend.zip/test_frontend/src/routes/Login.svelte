<script>
  import { push } from 'svelte-spa-router';
  import { auth, googleProvider, user } from '../lib/firebase';
  import { 
    signInWithEmailAndPassword,
    createUserWithEmailAndPassword,
    signInWithPopup,
    signOut
  } from 'firebase/auth';

  let email = '';
  let password = '';
  let error = '';

  // If user is already logged in, redirect to app
  user.subscribe((newUser) => {
    if (newUser) {
      push('/app');
    }
  });

  async function handleEmailSignIn() {
    try {
      error = '';
      await signInWithEmailAndPassword(auth, email, password);
      push('/app');
    } catch (e) {
      error = e.message;
    }
  }

  async function handleEmailSignUp() {
    try {
      error = '';
      await createUserWithEmailAndPassword(auth, email, password);
      push('/app');
    } catch (e) {
      error = e.message;
    }
  }

  async function handleGoogleSignIn() {
    try {
      error = '';
      await signInWithPopup(auth, googleProvider);
      push('/app');
    } catch (e) {
      error = e.message;
    }
  }

  function handleUnauthMode() {
    push('/app');
  }
</script>

<div class="login-container">
  <h1>Welcome to Clipmate</h1>
  
  <div class="auth-form">
    <input
      type="email"
      placeholder="Email"
      bind:value={email}
    />
    <input
      type="password"
      placeholder="Password"
      bind:value={password}
    />
    <div class="button-group">
      <button on:click={handleEmailSignIn}>Sign In</button>
      <button on:click={handleEmailSignUp}>Sign Up</button>
      <button on:click={handleGoogleSignIn} class="google-btn">
        Sign in with Google
      </button>
      <button on:click={handleUnauthMode} class="unauth-btn">
        Continue without Authentication
      </button>
    </div>
  </div>
  
  {#if error}
    <div class="error">
      {error}
    </div>
  {/if}
</div>

<style>
  .login-container {
    max-width: 400px;
    margin: 2rem auto;
    padding: 2rem;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    background: white;
  }

  h1 {
    text-align: center;
    margin-bottom: 2rem;
  }

  .auth-form {
    display: flex;
    flex-direction: column;
    gap: 1rem;
  }

  input {
    padding: 0.5rem;
    border: 1px solid #ccc;
    border-radius: 4px;
    font-size: 1rem;
  }

  .button-group {
    display: flex;
    flex-direction: column;
    gap: 0.5rem;
  }

  button {
    padding: 0.5rem 1rem;
    border: none;
    border-radius: 4px;
    font-size: 1rem;
    cursor: pointer;
    background-color: #4285f4;
    color: white;
    transition: background-color 0.2s;
  }

  button:hover {
    background-color: #357abd;
  }

  .google-btn {
    background-color: #db4437;
  }

  .google-btn:hover {
    background-color: #c23321;
  }

  .unauth-btn {
    background-color: #666;
  }

  .unauth-btn:hover {
    background-color: #555;
  }

  .error {
    color: #db4437;
    margin-top: 1rem;
    text-align: center;
  }
</style> 