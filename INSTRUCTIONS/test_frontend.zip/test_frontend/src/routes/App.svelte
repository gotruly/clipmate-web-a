<script lang="ts">
  import { onMount, onDestroy } from 'svelte';
  import { push } from 'svelte-spa-router';
  import { user, auth } from '../lib/firebase';
  import { fetchItems } from '../lib/api';

  const PAGE_SIZE = 45;
  let collections: any[] = [];
  let items: any[] = [];
  let currentPage = 0;
  let isLoading = false;
  let hasMoreItems = true;
  let selectedCollectionId: string | null = null;
  let filters = { itemTypes: [] as string[] };

  function truncate(str, length = 100) {
    if (!str) return '';
    return str.length > length ? str.slice(0, length) + '...' : str;
  }

  function extractDomain(url) {
    try {
      return new URL(url).hostname.replace('www.', '');
    } catch {
      return '';
    }
  }

  function updateFilters(newFilters) {
    if (filters.itemTypes?.[0] === newFilters.itemTypes?.[0]) {
      filters = { itemTypes: [] };
    } else {
      filters = { ...filters, ...newFilters };
    }
    items = [];
    currentPage = 0;
    hasMoreItems = true;
    fetchItemsWrapper(0);
  }

  async function fetchItemsWrapper(page: number) {
    if (!hasMoreItems) return;

    try {
      isLoading = true;

      let token: string | undefined;
      if ($user) {
        token = await $user.getIdToken();
      }

      const data = await fetchItems({
        page,
        PAGE_SIZE,
        filters,
        token,
        selectedCollectionId
      });

      if (data && data.items && data.collections) {
        collections = data.collections;
        if (page === 0) {
          items = data.items;
        } else {
          items = [...items, ...data.items];
        }
        hasMoreItems = (data.items.length === PAGE_SIZE);
      }
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      isLoading = false;
    }
  }

  function handleCollectionClick(collectionId) {
    selectedCollectionId = (selectedCollectionId === collectionId) ? null : collectionId;
    filters = { itemTypes: [] };
    items = [];
    currentPage = 0;
    hasMoreItems = true;
    fetchItemsWrapper(0);
  }

  function handleScroll() {
    const threshold = 300;
    const scrollPos = window.scrollY + window.innerHeight + threshold;
    if (scrollPos >= document.body.offsetHeight && !isLoading && hasMoreItems) {
      currentPage += 1;
      fetchItemsWrapper(currentPage);
    }
  }

  async function handleSignOut() {
    await auth.signOut();
    push('/');
  }

  onMount(() => {
    fetchItemsWrapper(0);
    window.addEventListener('scroll', handleScroll);
  });

  onDestroy(() => {
    window.removeEventListener('scroll', handleScroll);
  });
</script>

<div class="app-container">
  <header class="app-header">
    <h1>Clipmate</h1>
    <div class="user-info">
      {#if $user}
        <span>{$user.email}</span>
      {:else}
        <span>Unauthenticated Mode</span>
      {/if}
      <button on:click={handleSignOut}>Sign Out</button>
    </div>
  </header>

  <div class="content">
    <!-- Sidebar displaying collection names -->
    <aside class="sidebar">
      <!-- Add Sources section -->
      <section class="sources">
        <h2>Sources</h2>
        <div class="source-buttons">
          {#each ['link', 'reddit', 'twitter', 'github', 'PDF'] as source}
            <button 
              class:active={filters?.itemTypes?.includes(source)}
              on:click={() => updateFilters({ itemTypes: [source] })}
            >
              {source}
            </button>
          {/each}
        </div>
      </section>

      <section class="collections">
        <h2>Collections</h2>
        {#each collections as col}
          <div
            class="collection-item {selectedCollectionId === col.collectionId ? 'selected' : ''}"
            on:click={() => handleCollectionClick(col.collectionId)}
            on:keydown={(e) => {
              if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                handleCollectionClick(col.collectionId);
              }
            }}
            role="button"
            tabindex="0"
          >
            <span>{col.name}</span>
            {#if col.isPublic}
              <span class="badge public">public</span>
            {/if}
            <span class="badge count">{col.itemCount}</span>
          </div>
        {/each}
      </section>
    </aside>

    <!-- Main content area displaying items in a grid -->
    <main class="main">
      <div class="card-grid">
        {#each items as item}
          {#if item.type === 'twitter'}
            <div class="card twitter-card">
              <div class="twitter-author">
                <img src={item.data.author.profile_image_url} alt="" />
                <div>
                  <p>{item.data.author.name}</p>
                  <p>@{item.data.author.username}</p>
                </div>
              </div>
              <div class="twitter-content">
                {truncate(item.data.post.text, 150)}
              </div>
              {#if item.data.media?.length > 0}
                <div class="twitter-media">
                  {#each item.data.media as media}
                    <img
                      src={media.preview_image_url ? media.preview_image_url : media.url}
                      alt=""
                    />
                  {/each}
                </div>
              {/if}
            </div>

          {:else if item.type === 'reddit'}
            <div class="card reddit-card">
              <div class="reddit-header">
                <p>{item.data.post.subreddit_name_prefixed}</p>
              </div>
              <div class="reddit-content">
                <p>{item.data.post.title}</p>
                <div>
                  {truncate(item.data.post.selftext || '', 100)}
                </div>
              </div>
              {#if item.data.post.thumbnail && item.data.post.thumbnail !== 'self'}
                <div class="reddit-media">
                  <img src={item.data.post.thumbnail} alt="" />
                </div>
              {/if}
            </div>

          {:else if item.type === 'github'}
            <div class="card github-card">
              <div class="github-header">
                <img src={item.data.repo.owner.avatar_url} alt="" />
                <div>
                  <p>{item.data.repo.full_name}</p>
                </div>
              </div>
              <div class="github-content">
                {truncate(item.data.repo.description || '', 125)}
              </div>
              <div class="github-stats">
                <span>⭐ {item.data.repo.stargazers_count}</span>
                <span>🔀 {item.data.repo.forks_count}</span>
                <span>🐛 {item.data.repo.open_issues_count}</span>
              </div>
            </div>

          {:else if item.type === 'link'}
            <div class="card link-card">
              <div class="link-header">
                <div class="domain">{extractDomain(item.data.url)}</div>
                {#if item.data.image}
                  <div class="link-image">
                    <img src={item.data.image} alt="" />
                  </div>
                {/if}
              </div>
              <div class="link-content">
                <p>{item.data.title}</p>
                {#if item.data.description !== 'No description'}
                  <p>{truncate(item.data.description, 125)}</p>
                {/if}
              </div>
            </div>

          {:else}
            <div class="card">
              <div class="card-header">
                <span class="badge type">{item.type}</span>
              </div>
              <div class="card-data">
                {truncate(JSON.stringify(item.data), 100)}
              </div>
            </div>
          {/if}
        {/each}
      </div>
    </main>
  </div>
</div>

<style>
  html, body {
    margin: 0;
    padding: 0;
  }

  .app-container {
    display: flex;
    flex-direction: column;
    min-height: 100vh;
  }

  .app-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 1rem;
    background-color: #f8f9fa;
    border-bottom: 1px solid #dee2e6;
    position: sticky;
    top: 0;
    z-index: 10;
  }

  .user-info {
    display: flex;
    align-items: center;
    gap: 1rem;
  }

  .content {
    display: flex;
  }

  .sidebar {
    width: 250px;
    padding: 1rem;
    border-right: 1px solid #dee2e6;
    position: sticky;
    top: 4rem;
    height: calc(100vh - 4rem);
    overflow-y: auto;
  }

  .collection-item {
    padding: 0.5rem;
    margin-bottom: 0.5rem;
    border-radius: 4px;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 0.5rem;
  }

  .collection-item:hover {
    background-color: #f8f9fa;
  }

  .collection-item.selected {
    background-color: #e9ecef;
  }

  .badge {
    padding: 0.2rem 0.5rem;
    border-radius: 999px;
    font-size: 0.75rem;
  }

  .badge.public {
    background-color: #28a745;
    color: white;
  }

  .badge.count {
    background-color: #6c757d;
    color: white;
    margin-left: auto;
  }

  .main {
    flex: 1;
    padding: 1rem;
  }

  .card-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
    gap: 1rem;
  }

  .card {
    border: 1px solid #dee2e6;
    border-radius: 8px;
    padding: 1rem;
    background: white;
  }

  .card img {
    max-width: 100%;
    height: auto;
    display: block;
    object-fit: cover;
    border-radius: 4px;
  }

  .sources {
    margin-bottom: 2rem;
  }

  .source-buttons {
    display: flex;
    gap: 0.5rem;
    flex-wrap: wrap;
  }

  .source-buttons button {
    padding: 0.5rem 1rem;
    border: 1px solid #ddd;
    border-radius: 4px;
    background: white;
    cursor: pointer;
  }

  .source-buttons button.active {
    background: #007bff;
    color: white;
    border-color: #0056b3;
  }
</style> 